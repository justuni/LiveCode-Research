# Siva-Siva-Portal
**bkgnd "share-ui" of stack "Siva-Siva-Portal"**
* ID: bkgnd id 8191 of stack "Siva-Siva-Portal"
* Behavior: stack "behavior_SocialShare"

* Shared group on card IDs: 
* [stack_Siva-Siva-Portal_bkgnd_id_8191](./ScriptTracker/Siva-Siva-Portal_Scripts/stack_Siva-Siva-Portal_bkgnd_id_8191.livecodescript)

**widget "close-sharing" of bkgnd "share-ui" of stack "Siva-Siva-Portal"**
* ID: widget id 8193 of bkgnd id 8191 of stack "Siva-Siva-Portal"
* Widget Kind: com.livecode.widget.svgpath
* [stack_Siva-Siva-Portal_widget_id_8193](./ScriptTracker/Siva-Siva-Portal_Scripts/stack_Siva-Siva-Portal_widget_id_8193.livecodescript)

**bkgnd "modulesList" of stack "Siva-Siva-Portal"**
* ID: bkgnd id 53160 of stack "Siva-Siva-Portal"
* Behavior: button id 1005 of stack "revDataGridLibrary"

* Shared group on card IDs: 
* [stack_Siva-Siva-Portal_bkgnd_id_53160](./ScriptTracker/Siva-Siva-Portal_Scripts/stack_Siva-Siva-Portal_bkgnd_id_53160.livecodescript)

**bkgnd "footer" of stack "Siva-Siva-Portal"**
* ID: bkgnd id 55616 of stack "Siva-Siva-Portal"

* Background on card IDs: 53122
* [stack_Siva-Siva-Portal_bkgnd_id_55616](./ScriptTracker/Siva-Siva-Portal_Scripts/stack_Siva-Siva-Portal_bkgnd_id_55616.livecodescript)

**button "openGlobalNavTree" of bkgnd "bkgndControls" of stack "Siva-Siva-Portal"**
* ID: button id 57744 of bkgnd id 67444 of stack "Siva-Siva-Portal"
* [stack_Siva-Siva-Portal_button_id_57744](./ScriptTracker/Siva-Siva-Portal_Scripts/stack_Siva-Siva-Portal_button_id_57744.livecodescript)

**button "brandLogo" of bkgnd "bkgndControls" of stack "Siva-Siva-Portal"**
* ID: button id 55445 of bkgnd id 67444 of stack "Siva-Siva-Portal"
* [stack_Siva-Siva-Portal_button_id_55445](./ScriptTracker/Siva-Siva-Portal_Scripts/stack_Siva-Siva-Portal_button_id_55445.livecodescript)

**widget "turnOffAudio" of bkgnd "audioGlobalControl" of stack "Siva-Siva-Portal"**
* ID: widget id 53648 of bkgnd id 53647 of stack "Siva-Siva-Portal"
* Widget Kind: com.livecode.widget.svgpath
* [stack_Siva-Siva-Portal_widget_id_53648](./ScriptTracker/Siva-Siva-Portal_Scripts/stack_Siva-Siva-Portal_widget_id_53648.livecodescript)

**graphic "touchTrap" of bkgnd "loadingGroup" of stack "Siva-Siva-Portal"**
* ID: graphic id 67467 of bkgnd id 67466 of stack "Siva-Siva-Portal"
* [stack_Siva-Siva-Portal_graphic_id_67467](./ScriptTracker/Siva-Siva-Portal_Scripts/stack_Siva-Siva-Portal_graphic_id_67467.livecodescript)

**image "homeMainImage" of card "Home" of stack "Siva-Siva-Portal"**
* ID: image id 8189 of card id 8169 of stack "Siva-Siva-Portal"
* [stack_Siva-Siva-Portal_image_id_8189](./ScriptTracker/Siva-Siva-Portal_Scripts/stack_Siva-Siva-Portal_image_id_8189.livecodescript)

**button "PurgeStack" of card "Home" of stack "Siva-Siva-Portal"**
* ID: button id 65138 of card id 8169 of stack "Siva-Siva-Portal"
* [stack_Siva-Siva-Portal_button_id_65138](./ScriptTracker/Siva-Siva-Portal_Scripts/stack_Siva-Siva-Portal_button_id_65138.livecodescript)

**button "PurgeWindow" of card "Home" of stack "Siva-Siva-Portal"**
* ID: button id 65139 of card id 8169 of stack "Siva-Siva-Portal"
* [stack_Siva-Siva-Portal_button_id_65139](./ScriptTracker/Siva-Siva-Portal_Scripts/stack_Siva-Siva-Portal_button_id_65139.livecodescript)

**button "Create Tree Array" of card "Home" of stack "Siva-Siva-Portal"**
* ID: button id 67132 of card id 8169 of stack "Siva-Siva-Portal"
* [stack_Siva-Siva-Portal_button_id_67132](./ScriptTracker/Siva-Siva-Portal_Scripts/stack_Siva-Siva-Portal_button_id_67132.livecodescript)

**card "loader" of stack "Siva-Siva-Portal"**
* ID: card id 67353 of stack "Siva-Siva-Portal"
* [stack_Siva-Siva-Portal_card_id_67353](./ScriptTracker/Siva-Siva-Portal_Scripts/stack_Siva-Siva-Portal_card_id_67353.livecodescript)

