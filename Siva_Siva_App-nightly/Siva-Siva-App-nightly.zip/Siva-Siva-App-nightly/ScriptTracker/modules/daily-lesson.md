# daily-lesson
**stack "daily-lesson"**
* ID: stack "daily-lesson"
* [stack_daily-lesson_](./../../ScriptTracker/modules/daily-lesson_Scripts/stack_daily-lesson_.livecodescript)

**bkgnd "lessonTextControl" of stack "daily-lesson"**
* ID: bkgnd id 1146 of stack "daily-lesson"

* Background on card IDs: 1002
* [stack_daily-lesson_bkgnd_id_1146](./../../ScriptTracker/modules/daily-lesson_Scripts/stack_daily-lesson_bkgnd_id_1146.livecodescript)

**graphic "quoteBackground" of bkgnd "lessonTextControl" of stack "daily-lesson"**
* ID: graphic id 1147 of bkgnd id 1146 of stack "daily-lesson"
* [stack_daily-lesson_graphic_id_1147](./../../ScriptTracker/modules/daily-lesson_Scripts/stack_daily-lesson_graphic_id_1147.livecodescript)

**field "daily-lesson-text" of bkgnd "lessonTextControl" of stack "daily-lesson"**
* ID: field id 1148 of bkgnd id 1146 of stack "daily-lesson"
* Behavior: stack "behavior_mobileScroller"
* [stack_daily-lesson_field_id_1148](./../../ScriptTracker/modules/daily-lesson_Scripts/stack_daily-lesson_field_id_1148.livecodescript)

**widget "turnOffAudio" of bkgnd "audioGlobalControl" of stack "daily-lesson"**
* ID: widget id 1188 of bkgnd id 1187 of stack "daily-lesson"
* Widget Kind: com.livecode.widget.svgpath
* [stack_daily-lesson_widget_id_1188](./../../ScriptTracker/modules/daily-lesson_Scripts/stack_daily-lesson_widget_id_1188.livecodescript)

**card "daily-lesson" of stack "daily-lesson"**
* ID: card id 1002 of stack "daily-lesson"
* [stack_daily-lesson_card_id_1002](./../../ScriptTracker/modules/daily-lesson_Scripts/stack_daily-lesson_card_id_1002.livecodescript)

**button "left-arrow" of card "daily-lesson" of stack "daily-lesson"**
* ID: button id 1203 of card id 1002 of stack "daily-lesson"
* [stack_daily-lesson_button_id_1203](./../../ScriptTracker/modules/daily-lesson_Scripts/stack_daily-lesson_button_id_1203.livecodescript)

**button "right-arrow" of card "daily-lesson" of stack "daily-lesson"**
* ID: button id 1204 of card id 1002 of stack "daily-lesson"
* [stack_daily-lesson_button_id_1204](./../../ScriptTracker/modules/daily-lesson_Scripts/stack_daily-lesson_button_id_1204.livecodescript)

**group "share-ui" of card "daily-lesson" of stack "daily-lesson"**
* ID: group id 1190 of card id 1002 of stack "daily-lesson"
* Behavior: stack "behavior_SocialShare"
* [stack_daily-lesson_group_id_1190](./../../ScriptTracker/modules/daily-lesson_Scripts/stack_daily-lesson_group_id_1190.livecodescript)

**widget "close-sharing" of group "share-ui" of card "daily-lesson" of stack "daily-lesson"**
* ID: widget id 1192 of group id 1190 of card id 1002 of stack "daily-lesson"
* Widget Kind: com.livecode.widget.svgpath
* [stack_daily-lesson_widget_id_1192](./../../ScriptTracker/modules/daily-lesson_Scripts/stack_daily-lesson_widget_id_1192.livecodescript)

