# stories
**group "share-ui" of card "storiesHome" of stack "stories"**
* ID: group id 1301 of card id 1002 of stack "stories"
* Behavior: stack "behavior_SocialShare"
* [stack_stories_group_id_1301](./../../ScriptTracker/modules/stories_Scripts/stack_stories_group_id_1301.livecodescript)

**widget "close-sharing" of group "share-ui" of card "storiesHome" of stack "stories"**
* ID: widget id 1303 of group id 1301 of card id 1002 of stack "stories"
* Widget Kind: com.livecode.widget.svgpath
* [stack_stories_widget_id_1303](./../../ScriptTracker/modules/stories_Scripts/stack_stories_widget_id_1303.livecodescript)

**button "Edit Model Stories" of group "Tools" of card "storiesHome" of stack "stories"**
* ID: button id 1297 of group id 1298 of card id 1002 of stack "stories"
* [stack_stories_button_id_1297](./../../ScriptTracker/modules/stories_Scripts/stack_stories_button_id_1297.livecodescript)

**button "delete local-cache" of group "Tools" of card "storiesHome" of stack "stories"**
* ID: button id 1316 of group id 1298 of card id 1002 of stack "stories"
* [stack_stories_button_id_1316](./../../ScriptTracker/modules/stories_Scripts/stack_stories_button_id_1316.livecodescript)

**widget "goNext" of group "storyBoard" of card "showStories" of stack "stories"**
* ID: widget id 1295 of group id 1294 of card id 1291 of stack "stories"
* Widget Kind: com.livecode.widget.svgpath
* [stack_stories_widget_id_1295](./../../ScriptTracker/modules/stories_Scripts/stack_stories_widget_id_1295.livecodescript)

