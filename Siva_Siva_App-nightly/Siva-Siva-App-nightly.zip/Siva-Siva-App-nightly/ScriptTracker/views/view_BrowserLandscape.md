# view_BrowserLandscape
**bkgnd "share-ui" of stack "view_BrowserLandscape"**
* ID: bkgnd id 1292 of stack "view_BrowserLandscape"
* Behavior: stack "behavior_SocialShare"

* Shared group on card IDs: 
* [stack_view_BrowserLandscape_bkgnd_id_1292](./../ScriptTracker/views/view_BrowserLandscape_Scripts/stack_view_BrowserLandscape_bkgnd_id_1292.livecodescript)

**widget "close-sharing" of bkgnd "share-ui" of stack "view_BrowserLandscape"**
* ID: widget id 1294 of bkgnd id 1292 of stack "view_BrowserLandscape"
* Widget Kind: com.livecode.widget.svgpath
* [stack_view_BrowserLandscape_widget_id_1294](./../ScriptTracker/views/view_BrowserLandscape_Scripts/stack_view_BrowserLandscape_widget_id_1294.livecodescript)

**bkgnd "share-ui" of stack "view_BrowserLandscape"**
* ID: bkgnd id 1305 of stack "view_BrowserLandscape"
* Behavior: stack "behavior_SocialShare"

* Shared group on card IDs: 
* [stack_view_BrowserLandscape_bkgnd_id_1305](./../ScriptTracker/views/view_BrowserLandscape_Scripts/stack_view_BrowserLandscape_bkgnd_id_1305.livecodescript)

**widget "close-sharing" of bkgnd "share-ui" of stack "view_BrowserLandscape"**
* ID: widget id 1307 of bkgnd id 1305 of stack "view_BrowserLandscape"
* Widget Kind: com.livecode.widget.svgpath
* [stack_view_BrowserLandscape_widget_id_1307](./../ScriptTracker/views/view_BrowserLandscape_Scripts/stack_view_BrowserLandscape_widget_id_1307.livecodescript)

**bkgnd "share-ui" of stack "view_BrowserLandscape"**
* ID: bkgnd id 1321 of stack "view_BrowserLandscape"
* Behavior: stack "behavior_SocialShare"

* Shared group on card IDs: 
* [stack_view_BrowserLandscape_bkgnd_id_1321](./../ScriptTracker/views/view_BrowserLandscape_Scripts/stack_view_BrowserLandscape_bkgnd_id_1321.livecodescript)

**widget "close-sharing" of bkgnd "share-ui" of stack "view_BrowserLandscape"**
* ID: widget id 1323 of bkgnd id 1321 of stack "view_BrowserLandscape"
* Widget Kind: com.livecode.widget.svgpath
* [stack_view_BrowserLandscape_widget_id_1323](./../ScriptTracker/views/view_BrowserLandscape_Scripts/stack_view_BrowserLandscape_widget_id_1323.livecodescript)

**bkgnd "share-ui" of stack "view_BrowserLandscape"**
* ID: bkgnd id 1337 of stack "view_BrowserLandscape"
* Behavior: stack "behavior_SocialShare"

* Shared group on card IDs: 
* [stack_view_BrowserLandscape_bkgnd_id_1337](./../ScriptTracker/views/view_BrowserLandscape_Scripts/stack_view_BrowserLandscape_bkgnd_id_1337.livecodescript)

**widget "close-sharing" of bkgnd "share-ui" of stack "view_BrowserLandscape"**
* ID: widget id 1339 of bkgnd id 1337 of stack "view_BrowserLandscape"
* Widget Kind: com.livecode.widget.svgpath
* [stack_view_BrowserLandscape_widget_id_1339](./../ScriptTracker/views/view_BrowserLandscape_Scripts/stack_view_BrowserLandscape_widget_id_1339.livecodescript)

**button "Load HTML" of card "SivaSivaBrowser" of stack "view_BrowserLandscape"**
* ID: button id 1431 of card id 1002 of stack "view_BrowserLandscape"
* [stack_view_BrowserLandscape_button_id_1431](./../ScriptTracker/views/view_BrowserLandscape_Scripts/stack_view_BrowserLandscape_button_id_1431.livecodescript)

**group "footerNavigation" of card "SivaSivaBrowser" of stack "view_BrowserLandscape"**
* ID: group id 1006 of card id 1002 of stack "view_BrowserLandscape"
* [stack_view_BrowserLandscape_group_id_1006](./../ScriptTracker/views/view_BrowserLandscape_Scripts/stack_view_BrowserLandscape_group_id_1006.livecodescript)

**group "share-ui" of card "SivaSivaBrowser" of stack "view_BrowserLandscape"**
* ID: group id 1432 of card id 1002 of stack "view_BrowserLandscape"
* Behavior: stack "behavior_SocialShare"
* [stack_view_BrowserLandscape_group_id_1432](./../ScriptTracker/views/view_BrowserLandscape_Scripts/stack_view_BrowserLandscape_group_id_1432.livecodescript)

**button "Change URL" of card id 1405 of stack "view_BrowserLandscape"**
* ID: button id 1408 of card id 1405 of stack "view_BrowserLandscape"
* [stack_view_BrowserLandscape_button_id_1408](./../ScriptTracker/views/view_BrowserLandscape_Scripts/stack_view_BrowserLandscape_button_id_1408.livecodescript)

**widget "SVG Icon" of card id 1405 of stack "view_BrowserLandscape"**
* ID: widget id 1413 of card id 1405 of stack "view_BrowserLandscape"
* Widget Kind: com.livecode.widget.svgpath
* [stack_view_BrowserLandscape_widget_id_1413](./../ScriptTracker/views/view_BrowserLandscape_Scripts/stack_view_BrowserLandscape_widget_id_1413.livecodescript)

**card "Loader" of stack "view_BrowserLandscape"**
* ID: card id 1419 of stack "view_BrowserLandscape"
* [stack_view_BrowserLandscape_card_id_1419](./../ScriptTracker/views/view_BrowserLandscape_Scripts/stack_view_BrowserLandscape_card_id_1419.livecodescript)

