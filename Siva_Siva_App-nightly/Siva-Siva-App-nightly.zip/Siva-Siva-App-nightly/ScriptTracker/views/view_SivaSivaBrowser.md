# view_SivaSivaBrowser
**group "footerNavigation" of card "SivaSivaBrowser" of stack "view_SivaSivaBrowser"**
* ID: group id 1006 of card id 1002 of stack "view_SivaSivaBrowser"
* [stack_view_SivaSivaBrowser_group_id_1006](./../ScriptTracker/views/view_SivaSivaBrowser_Scripts/stack_view_SivaSivaBrowser_group_id_1006.livecodescript)

**button "Load HTML" of card "SivaSivaBrowser" of stack "view_SivaSivaBrowser"**
* ID: button id 1431 of card id 1002 of stack "view_SivaSivaBrowser"
* [stack_view_SivaSivaBrowser_button_id_1431](./../ScriptTracker/views/view_SivaSivaBrowser_Scripts/stack_view_SivaSivaBrowser_button_id_1431.livecodescript)

**group "share-ui" of card "SivaSivaBrowser" of stack "view_SivaSivaBrowser"**
* ID: group id 1432 of card id 1002 of stack "view_SivaSivaBrowser"
* Behavior: stack "behavior_SocialShare"
* [stack_view_SivaSivaBrowser_group_id_1432](./../ScriptTracker/views/view_SivaSivaBrowser_Scripts/stack_view_SivaSivaBrowser_group_id_1432.livecodescript)

**button "Change URL" of card id 1405 of stack "view_SivaSivaBrowser"**
* ID: button id 1408 of card id 1405 of stack "view_SivaSivaBrowser"
* [stack_view_SivaSivaBrowser_button_id_1408](./../ScriptTracker/views/view_SivaSivaBrowser_Scripts/stack_view_SivaSivaBrowser_button_id_1408.livecodescript)

**widget "SVG Icon" of card id 1405 of stack "view_SivaSivaBrowser"**
* ID: widget id 1413 of card id 1405 of stack "view_SivaSivaBrowser"
* Widget Kind: com.livecode.widget.svgpath
* [stack_view_SivaSivaBrowser_widget_id_1413](./../ScriptTracker/views/view_SivaSivaBrowser_Scripts/stack_view_SivaSivaBrowser_widget_id_1413.livecodescript)

**card "Loader" of stack "view_SivaSivaBrowser"**
* ID: card id 1419 of stack "view_SivaSivaBrowser"
* [stack_view_SivaSivaBrowser_card_id_1419](./../ScriptTracker/views/view_SivaSivaBrowser_Scripts/stack_view_SivaSivaBrowser_card_id_1419.livecodescript)

