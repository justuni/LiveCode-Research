# ha_RigApplication
This repository is for the www.himalayanacademy.com web site.

As a start we have checked out the existing site on dev.himalayanacademy.com in the revIgniter application folder whch can be found at the following path:

  - /home/devhap/public_html/system/application/ha

## Removing old git project
It looks like there was a big old git project initiated for the whole public_html folder. I deleted the .git folder for this. I also did the same for the ha folder and it's subfolders in case there were any passwords etc in old histories.

## Checkout and add to GitHub
You can view further help regarding this repository over at:

  - http://dev.himalayan.academy/harigapplication.html

