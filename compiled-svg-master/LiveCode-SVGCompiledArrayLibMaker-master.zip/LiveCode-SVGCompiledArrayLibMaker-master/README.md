# LiveCode-SVGCompiledArrayLibMaker
A LiveCode stack that converts multiple SVG files into Script-only Library stacks that when put in use load a global array of pre-compiled binary SVG Data which can be used to very quickly fill an image box.
