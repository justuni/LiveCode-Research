# lcw_GIT
A project to interact with git and Github.

here I can list things like the libraries it contains.
