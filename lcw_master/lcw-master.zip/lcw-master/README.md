# LiveWorld
This repository contains the core script-only components of Livecode World. Unfortunatley it has grown a litlle too large.
